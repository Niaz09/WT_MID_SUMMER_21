<html>
	<body>
		<form>
			<table>
				<tr>
					<td><h1>Booking Information</h1></td>
				</tr>
				<tr>
					<td align="right">Name:</td>
					<td><input type="text"></td>
				</tr>
				<tr>
					<td align="right">Phone:</td>
					<td><input type="text"></td>
				</tr>
				<tr>
					<td align="right">Email:</td>
					<td><input type="text"></td>
				</tr>
				<tr>
					<td align="right">Address:</td>
					<td><input type="text"></td>
				</tr>
				<tr>
					<td align="right">NID:</td>
					<td><input type="text"></td>
				</tr>
			</table>
		</form>
	</body>
</html>